import mysql.connector
from mysql.connector import Error

class Database:
    def __init__(self):
        self.connection = None
        try:
            self.connection = mysql.connector.connect(
                host='localhost',
                database='insider_trading',
                user='root',
                password=''  # Update with your XAMPP MySQL password if set
            )
        except Error as e:
            print(f"Error connecting to MySQL: {e}")

    def execute_query(self, query, params=None):
        cursor = self.connection.cursor()
        try:
            cursor.execute(query, params or ())
            self.connection.commit()
            return cursor
        except Error as e:
            print(f"Error executing query: {e}")
            return None

    def fetch_query(self, query, params=None):
        cursor = self.connection.cursor(buffered=True)  # Buffered cursor
        try:
            cursor.execute(query, params or ())
            results = cursor.fetchall()
            while cursor.nextset():  # Consume all result sets
                pass
            cursor.close()
            return results
        except Error as e:
            print(f"Error executing query: {e}")
            cursor.close()
            return []

    def close(self):
        if self.connection and self.connection.is_connected():
            self.connection.close()