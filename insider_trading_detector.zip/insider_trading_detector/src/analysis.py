from db_connect import Database

class TradeAnalyzer:
    def __init__(self):
        self.db = Database()

    def add_trade(self, user_id, stock_id, trade_type, quantity, price, trade_date):
        query = """
        INSERT INTO trades (user_id, stock_id, trade_type, quantity, price, trade_date)
        VALUES (%s, %s, %s, %s, %s, %s)
        """
        self.db.execute_query(query, (user_id, stock_id, trade_type, quantity, price, trade_date))

    def add_stock_price(self, stock_id, price_date, closing_price):
        query = """
        INSERT INTO stock_prices (stock_id, price_date, closing_price)
        VALUES (%s, %s, %s)
        """
        self.db.execute_query(query, (stock_id, price_date, closing_price))

    def get_suspicious_trades(self, user_id):
        query = "CALL GetSuspiciousTradesByUser(%s)"
        cursor = self.db.connection.cursor(buffered=True)
        try:
            results = []
            for result in cursor.execute(query, (user_id,), multi=True):
                if result.with_rows:
                    results.extend(result.fetchall())
            cursor.close()
            return results
        except Exception as e:
            print(f"Error in get_suspicious_trades: {e}")
            cursor.close()
            return []

    def get_all_trades(self):
        query = """
        SELECT t.trade_id, u.username, s.symbol, t.trade_type, t.quantity, 
               t.price, t.trade_date
        FROM trades t
        JOIN users u ON t.user_id = u.user_id
        JOIN stocks s ON t.stock_id = s.stock_id
        """
        return self.db.fetch_query(query)