
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
from analysis import TradeAnalyzer

class InsiderTradingGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Insider Trading Detector")
        self.analyzer = TradeAnalyzer()
        
        # Configure root window
        self.root.configure(bg='#FF6200')  # Orange background
        self.root.geometry("600x650")  # Fixed size
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)
        
        # Style configuration
        style = ttk.Style()
        style.theme_use('default')
        
        # Button styling
        style.configure('Custom.TButton', 
                       font=('Trebuchet MS', 12), 
                       foreground='black', 
                       background='#FF6200',
                       padding=10)
        style.map('Custom.TButton', 
                 background=[('active', '#E05500')],  # Darker orange on hover
                 foreground=[('active', 'black')])
        
        # Label styling
        style.configure('Custom.TLabel', 
                       font=('Trebuchet MS', 14, 'bold'), 
                       foreground='black', 
                       background='#FF6200')
        
        # Entry styling
        style.configure('Custom.TEntry', 
                       font=('Georgia', 12), 
                       foreground='black',
                       fieldbackground='#FF6200')
        
        # Combobox styling
        style.configure('Custom.TCombobox', 
                       font=('Georgia', 12), 
                       foreground='black',
                       fieldbackground='#FF6200')
        
        # Treeview styling
        style.configure('Custom.Treeview', 
                       font=('Georgia', 11), 
                       foreground='black', 
                       background='#FF6200',  # Orange background for treeview
                       fieldbackground='#FFFFFF')  # White cell background
        style.configure('Custom.Treeview.Heading', 
                       font=('Georgia', 12, 'bold'), 
                       foreground='black',
                       background='#FF6200')
        style.map('Custom.Treeview', 
                 background=[('selected', '#E05500')])
        
        # Frame styling
        style.configure('Custom.TFrame', 
                       background='#FF6200')
        
        # Main frame
        self.main_frame = ttk.Frame(self.root, padding="15", style='Custom.TFrame')
        self.main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        self.main_frame.configure(borderwidth=2, relief='groove')
        
        self.main_frame.grid_rowconfigure(9, weight=1)
        self.main_frame.grid_columnconfigure(0, weight=1)
        self.main_frame.grid_columnconfigure(1, weight=1)
        
        # Trade input section
        ttk.Label(self.main_frame, text="Add Trade", style='Custom.TLabel').grid(row=0, column=0, columnspan=2, pady=10)
        
        ttk.Label(self.main_frame, text="User ID:", style='Custom.TLabel').grid(row=1, column=0, sticky=tk.W, padx=5)
        self.user_id = ttk.Entry(self.main_frame, style='Custom.TEntry')
        self.user_id.grid(row=1, column=1, pady=5, padx=5, sticky=(tk.W, tk.E))
        self.user_id.bind('<FocusIn>', lambda e: self.user_id.configure(background='#FFFFCC'))
        self.user_id.bind('<FocusOut>', lambda e: self.user_id.configure(background='#FFFFFF'))
        
        ttk.Label(self.main_frame, text="Stock ID:", style='Custom.TLabel').grid(row=2, column=0, sticky=tk.W, padx=5)
        self.stock_id = ttk.Entry(self.main_frame, style='Custom.TEntry')
        self.stock_id.grid(row=2, column=1, pady=5, padx=5, sticky=(tk.W, tk.E))
        self.stock_id.bind('<FocusIn>', lambda e: self.stock_id.configure(background='#FFFFCC'))
        self.stock_id.bind('<FocusOut>', lambda e: self.stock_id.configure(background='#FFFFFF'))
        
        ttk.Label(self.main_frame, text="Trade Type:", style='Custom.TLabel').grid(row=3, column=0, sticky=tk.W, padx=5)
        self.trade_type = ttk.Combobox(self.main_frame, values=["BUY", "SELL"], style='Custom.TCombobox')
        self.trade_type.grid(row=3, column=1, pady=5, padx=5, sticky=(tk.W, tk.E))
        
        ttk.Label(self.main_frame, text="Quantity:", style='Custom.TLabel').grid(row=4, column=0, sticky=tk.W, padx=5)
        self.quantity = ttk.Entry(self.main_frame, style='Custom.TEntry')
        self.quantity.grid(row=4, column=1, pady=5, padx=5, sticky=(tk.W, tk.E))
        self.quantity.bind('<FocusIn>', lambda e: self.quantity.configure(background='#FFFFCC'))
        self.quantity.bind('<FocusOut>', lambda e: self.quantity.configure(background='#FFFFFF'))
        
        ttk.Label(self.main_frame, text="Price:", style='Custom.TLabel').grid(row=5, column=0, sticky=tk.W, padx=5)
        self.price = ttk.Entry(self.main_frame, style='Custom.TEntry')
        self.price.grid(row=5, column=1, pady=5, padx=5, sticky=(tk.W, tk.E))
        self.price.bind('<FocusIn>', lambda e: self.price.configure(background='#FFFFCC'))
        self.price.bind('<FocusOut>', lambda e: self.price.configure(background='#FFFFFF'))
        
        ttk.Label(self.main_frame, text="Trade Date (YYYY-MM-DD):", style='Custom.TLabel').grid(row=6, column=0, sticky=tk.W, padx=5)
        self.trade_date = ttk.Entry(self.main_frame, style='Custom.TEntry')
        self.trade_date.grid(row=6, column=1, pady=5, padx=5, sticky=(tk.W, tk.E))
        self.trade_date.bind('<FocusIn>', lambda e: self.trade_date.configure(background='#FFFFCC'))
        self.trade_date.bind('<FocusOut>', lambda e: self.trade_date.configure(background='#FFFFFF'))
        
        ttk.Button(self.main_frame, text="Add Trade", command=self.add_trade, style='Custom.TButton').grid(row=7, column=0, columnspan=2, pady=15)
        
        # Report section
        ttk.Button(self.main_frame, text="View All Trades", command=self.view_trades, style='Custom.TButton').grid(row=8, column=0, padx=5, pady=10)
        ttk.Button(self.main_frame, text="View Suspicious Trades", command=self.view_suspicious, style='Custom.TButton').grid(row=8, column=1, padx=5, pady=10)
        
        # Treeview for results
        self.tree = ttk.Treeview(self.main_frame, 
                                columns=("ID", "User", "Stock", "Type", "Quantity", "Price", "Date"), 
                                show="headings", 
                                style='Custom.Treeview')
        self.tree.grid(row=9, column=0, columnspan=2, pady=10, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        self.tree.heading("ID", text="Trade ID")
        self.tree.heading("User", text="Username")
        self.tree.heading("Stock", text="Stock")
        self.tree.heading("Type", text="Type")
        self.tree.heading("Quantity", text="Quantity")
        self.tree.heading("Price", text="Price")
        self.tree.heading("Date", text="Date")
        
        # Set column widths
        self.tree.column("ID", width=60)
        self.tree.column("User", width=100)
        self.tree.column("Stock", width=80)
        self.tree.column("Type", width=80)
        self.tree.column("Quantity", width=80)
        self.tree.column("Price", width=80)
        self.tree.column("Date", width=120)
        
        # Alternating row colors
        self.tree.tag_configure('oddrow', background='#FFFFFF')
        self.tree.tag_configure('evenrow', background='#FFE4B5')

    def add_trade(self):
        try:
            user_id = int(self.user_id.get())
            stock_id = int(self.stock_id.get())
            trade_type = self.trade_type.get()
            quantity = int(self.quantity.get())
            price = float(self.price.get())
            trade_date = datetime.strptime(self.trade_date.get(), '%Y-%m-%d')
            
            self.analyzer.add_trade(user_id, stock_id, trade_type, quantity, price, trade_date)
            messagebox.showinfo("Success", "Trade added successfully!", parent=self.root)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to add trade: {e}", parent=self.root)

    def view_trades(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        trades = self.analyzer.get_all_trades()
        for i, trade in enumerate(trades):
            tag = 'evenrow' if i % 2 == 0 else 'oddrow'
            self.tree.insert("", tk.END, values=trade, tags=(tag,))

    def view_suspicious(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        user_id = self.user_id.get()
        if not user_id:
            messagebox.showerror("Error", "Please enter a User ID", parent=self.root)
            return
            
        trades = self.analyzer.get_suspicious_trades(int(user_id))
        for i, trade in enumerate(trades):
            tag = 'evenrow' if i % 2 == 0 else 'oddrow'
            self.tree.insert("", tk.END, values=trade, tags=(tag,))

if __name__ == "__main__":
    root = tk.Tk()
    app = InsiderTradingGUI(root)
    root.mainloop()