-- Create database
CREATE DATABASE IF NOT EXISTS insider_trading;
USE insider_trading;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Stocks table
CREATE TABLE IF NOT EXISTS stocks (
    stock_id INT PRIMARY KEY AUTO_INCREMENT,
    symbol VARCHAR(10) NOT NULL,
    company_name VARCHAR(100)
);

-- Stock prices history
CREATE TABLE IF NOT EXISTS stock_prices (
    price_id INT PRIMARY KEY AUTO_INCREMENT,
    stock_id INT,
    price_date DATE NOT NULL,
    closing_price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (stock_id) REFERENCES stocks(stock_id)
);

-- Trades table
CREATE TABLE IF NOT EXISTS trades (
    trade_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    stock_id INT,
    trade_type ENUM('BUY', 'SELL') NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    trade_date DATETIME NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (stock_id) REFERENCES stocks(stock_id)
);

-- Suspicious trades table
CREATE TABLE IF NOT EXISTS suspicious_trades (
    suspicious_id INT PRIMARY KEY AUTO_INCREMENT,
    trade_id INT,
    reason VARCHAR(255),
    flagged_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (trade_id) REFERENCES trades(trade_id)
);

-- Trigger for suspicious trades
DELIMITER //
CREATE TRIGGER IF NOT EXISTS detect_suspicious_trade
AFTER INSERT ON trades
FOR EACH ROW
BEGIN
    DECLARE next_day_price DECIMAL(10,2);
    DECLARE price_change_percent DECIMAL(10,2);
    
    -- Get next day's price
    SELECT closing_price INTO next_day_price
    FROM stock_prices
    WHERE stock_id = NEW.stock_id
    AND price_date = DATE_ADD(NEW.trade_date, INTERVAL 1 DAY)
    LIMIT 1;
    
    -- Calculate price change
    IF next_day_price IS NOT NULL THEN
        SET price_change_percent = ((next_day_price - NEW.price) / NEW.price) * 100;
        
        -- Flag suspicious trades
        IF (NEW.trade_type = 'BUY' AND price_change_percent > 10) OR 
           (NEW.trade_type = 'SELL' AND price_change_percent < -10) THEN
            INSERT INTO suspicious_trades (trade_id, reason)
            VALUES (NEW.trade_id, 
                   CONCAT('Suspicious ', NEW.trade_type, ': ', 
                          ABS(price_change_percent), '% price change in 1 day'));
        END IF;
    END IF;
END //
DELIMITER ;

-- Stored procedure for reports
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS GetSuspiciousTradesByUser(IN p_user_id INT)
BEGIN
    SELECT 
        u.username,
        t.trade_id,
        s.symbol,
        t.trade_type,
        t.quantity,
        t.price,
        t.trade_date,
        st.reason,
        st.flagged_at
    FROM suspicious_trades st
    JOIN trades t ON st.trade_id = t.trade_id
    JOIN users u ON t.user_id = u.user_id
    JOIN stocks s ON t.stock_id = s.stock_id
    WHERE u.user_id = p_user_id
    ORDER BY st.flagged_at DESC;
END //
DELIMITER ;

-- Sample data
INSERT IGNORE INTO users (username, email) VALUES 
('john_doe', 'john@example.com'),
('jane_smith', 'jane@example.com');

INSERT IGNORE INTO stocks (symbol, company_name) VALUES 
('AAPL', 'Apple Inc.'),
('GOOGL', 'Alphabet Inc.');

INSERT IGNORE INTO stock_prices (stock_id, price_date, closing_price) VALUES
(1, '2025-06-01', 150.00),
(1, '2025-06-02', 165.00),
(2, '2025-06-01', 2700.00),
(2, '2025-06-02', 2400.00);